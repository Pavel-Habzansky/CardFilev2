/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
    Tento "projekt" je simulací virtuální kartotéky, který ukládá data do
    databáze a načítá z ní. 
    Data se zobrazují v TableView v přehledné formě, funguje i real-time 
    vyhledávání pacientů na základě zadaného textu.
    Okenní aplikace je provedena pomocí JavaFX.
*/
package cardfilev2;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Optional;
import java.util.function.Predicate;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author PavelHabzansky
 */
public class CardFileV2 extends Application {
    
    @Override
    @SuppressWarnings("unchecked")
    public void start(Stage primaryStage) {
        // Hlavní VBox, který tvoří podklad okna.
        VBox mainBox = new VBox();
        
        /* HBox, který tvoří spodní část okna, obsahuje další 
           boxy*/  
        HBox bottomBox = new HBox(); 
        // Jeden ze "subboxů", které obsahují ovládací a vstupní prvky
        // subBottomBox1 obsahuje TextFieldy pro vkládání jmena, přijmení a adresy
        VBox subBottomBox1 = new VBox();
        subBottomBox1.setSpacing(10);
        subBottomBox1.setPadding(new Insets(20, 5, 10, 20));
        TextField nameField = new TextField();
        nameField.setPromptText("Jmeno");
        TextField surnameField = new TextField();
        surnameField.setPromptText("Prijmeni");
        TextField addressField = new TextField();
        addressField.setPromptText("Adresa");
        subBottomBox1.getChildren().addAll(nameField,surnameField,addressField);
        
        // subBottomBox2 obsahuje DOBBox pro zadávání data narození a TextFieldy pro rodné číslo a telefonní číslo
        VBox subBottomBox2 = new VBox();
        subBottomBox2.setSpacing(10);
        subBottomBox2.setPadding(new Insets(20, 5, 10, 20));
        HBox DOBBox = new HBox();
        DOBBox.setSpacing(10);
        ComboBox<String> yearComboBox = new ComboBox<>();
        yearComboBox.setPromptText("Rok");
        ComboBox<String> monthComboBox = new ComboBox<>();
        monthComboBox.setPromptText("Mesic");
        ComboBox<String> dayComboBox = new ComboBox<>();
        dayComboBox.setPromptText("Den");
        // Naplnění ComboBoxu s rokem narození, měsícem narození a dnem narození
        for(int i = LocalDate.now().getYear();i >= 1920;i--)
            yearComboBox.getItems().add(Integer.toString(i));       
        for (int i = 1; i <= 12; i++) 
            monthComboBox.getItems().add(Integer.toString(i));
        for (int i = 1; i < 31; i++) 
            dayComboBox.getItems().add(Integer.toString(i));
        DOBBox.getChildren().addAll(yearComboBox,monthComboBox,dayComboBox);
        
        TextField birthCertificateNumberField = new TextField();
        birthCertificateNumberField.setPromptText("Rodne cislo");
        TextField phoneNumberField = new TextField();
        phoneNumberField.setPromptText("Telefonni cislo");
        subBottomBox2.getChildren().addAll(DOBBox,birthCertificateNumberField,phoneNumberField);
        
        // subBottomBox4 obsahuje ComboBox pro výběr pohlaví
        VBox subBottomBox4 = new VBox();
        subBottomBox4.setSpacing(10);
        subBottomBox4.setPadding(new Insets(20, 5, 10, 20));
        ComboBox<String> genderComboBox = new ComboBox<>();
        genderComboBox.getItems().addAll("Muz", "Zena");
        genderComboBox.setPromptText("Pohlavi");
        subBottomBox4.getChildren().addAll(genderComboBox);
        
        // subBottomBox6 obsahuje další boxy s ovládacími prvky
        VBox subBottomBox6 = new VBox();
        subBottomBox6.setSpacing(10);
        subBottomBox6.setPadding(new Insets(20, 5, 10, 20));
        
        // subBottomBox7 obsahuje tlačítka pro přidání a odebrání pacients z ObservableList a DB
        HBox subBottomBox7 = new HBox();
        subBottomBox7.setSpacing(10);
        subBottomBox7.setPadding(new Insets(0, 5, 10, 0));
        Button addButton = new Button("Pridat");
        Button deleteButton = new Button("Odebrat");
        subBottomBox7.getChildren().addAll(addButton,deleteButton);
        
        // subBottomBox8 obsahuje TextField pro real-time vyhledávání pacientů
        VBox subBottomBox8 = new VBox();
        subBottomBox8.setSpacing(10);
        subBottomBox8.setPadding(new Insets(0, 5, 10, 0));
        TextField filterField = new TextField();
        filterField.setPromptText("Filtrovat");
        Button clearButton = new Button("Vyprazdnit");
        subBottomBox8.getChildren().addAll(filterField,clearButton);
        
        subBottomBox6.getChildren().addAll(subBottomBox7,subBottomBox8);
        bottomBox.getChildren().addAll(subBottomBox1,subBottomBox2,subBottomBox4,
                subBottomBox6);
        
        // Jednoduché menu...
        Menu fileMenu = new Menu("File");
        MenuBar menuBar = new MenuBar(fileMenu);
        MenuItem closeMenuItem = new MenuItem("Zavrit");
        fileMenu.getItems().add(closeMenuItem);
        
        // TableView pro zobrazení pacientů a ObservableList pro jejich ukládání
        TableView<Patient> patientTableView = new TableView<>();
        patientTableView.setPrefHeight(300);
        ObservableList<Patient> patientObsList = FXCollections.observableArrayList();
        
        // Vkládání testovacích dat...
        patientObsList.addAll(new Patient("123456/1234", "Jan", 
                "Novak", "Namesti republiky 3", LocalDate.of(1970,12,12), "Muz", 123456789),
                new Patient("123456/1235", "Eva", 
                "Vomackova", "Indianska 5", LocalDate.of(1990, 12, 4), "Zena", 123456789),
                new Patient("123456/1236", "Tomas", 
                "Jagr", "Prazska 14", LocalDate.of(1950,5,12), "Muz", 123456789),
                new Patient("123456/1237", "Ivana", 
                "Ivanovova", "Moskevska 56", LocalDate.of(1985,2,23), "Zena", 123456789),
                new Patient("123456/1238", "Milada", 
                "Novotna", "Komenskeho 34", LocalDate.of(1976,7,4), "Zena", 123456789),
                new Patient("123456/1239", "Petr", 
                "Cerny", "Koterovska 65", LocalDate.of(1998,6,21), "Muz", 123456789),
                new Patient("123456/1230", "Zlata", 
                "Panská", "Parizska 23", LocalDate.of(1943,6,17), "Zena", 123456789));
        
        mainBox.getChildren().addAll(menuBar,patientTableView,bottomBox);
      
        // Připojování k DB, ze které se do ObservableList načtou pomocí cyklu pacienti
        // Připojení probíhá při spuštění programu
        try(Connection connectDB = DriverManager.getConnection
        ("jdbc:mysql://localhost/mysql?user=root&password=");
                PreparedStatement query = connectDB.prepareStatement("SELECT * FROM Patients");
                ResultSet results = query.executeQuery();){
            
            while(results.next()){
                Patient newPatient = new Patient(results.getString("patientBCN"),
                        results.getString("patientName"), results.getString("patientSurname"), 
                        results.getString("patientAddress"), 
                        results.getDate("patientDOB").toLocalDate(), results.getString("patientGender"),
                        results.getLong("patientPhoneNumber"));
                patientObsList.add(newPatient);
            }
        }
        catch(SQLException ex){
            System.err.println(ex.getMessage());
        }
        
        // Inicializace konkrétních sloupců TableView pro zobrazení informací o pacientech
        TableColumn<Patient, String> bcnColumn = new TableColumn<>("Rodne cislo");
        bcnColumn.setPrefWidth(100);
        bcnColumn.setCellValueFactory(new PropertyValueFactory<>("birthCertificateNumber"));
        TableColumn<Patient, String> nameColumn = new TableColumn<>("Jmeno");
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        TableColumn<Patient, String> surnameColumn = new TableColumn<>("Prijmeni");
        surnameColumn.setCellValueFactory(new PropertyValueFactory<>("surname"));
        TableColumn<Patient, String> addressColumn = new TableColumn<>("Adresa");
        addressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
        TableColumn<Patient, LocalDate> dobColumn = new TableColumn<>("Narozen");
        dobColumn.setCellValueFactory(new PropertyValueFactory<>("dateOfBirth"));
        TableColumn<Patient, Long> ageColumn = new TableColumn<>("Vek");
        ageColumn.setCellValueFactory(new PropertyValueFactory<>("age"));
        TableColumn<Patient, Long> phoneNumberColumn = new TableColumn<>("Telefonni cislo");
        phoneNumberColumn.setPrefWidth(150);
        phoneNumberColumn.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        TableColumn<Patient, String> genderColumn = new TableColumn<>("Pohlavi");
        genderColumn.setCellValueFactory(new PropertyValueFactory<>("gender"));
        
        // Přidání pacientů z ObservableList do TableView
        patientTableView.setItems(patientObsList);
        patientTableView.getColumns().addAll(bcnColumn,nameColumn,surnameColumn,
                addressColumn,dobColumn,ageColumn,phoneNumberColumn,genderColumn);
        
        Scene scene = new Scene(mainBox, 800, 500);
        
        primaryStage.setTitle("CardFile");
        primaryStage.setScene(scene);
        primaryStage.show();
        
        // Obsluha tlačítka pro přidání pacienta do DB/ObservableListu
        addButton.setOnAction(e->{
            if(nameField.getText()==null ||
                    surnameField.getText()==null ||
                    addressField.getText()==null ||
                    yearComboBox.getSelectionModel().getSelectedIndex() == 0 ||
                    monthComboBox.getSelectionModel().getSelectedIndex() == 0 ||
                    dayComboBox.getSelectionModel().getSelectedIndex() == 0 ||
                    birthCertificateNumberField.getText()==null ||
                    genderComboBox.getSelectionModel().getSelectedItem()=="Pohlavi"){
                Alert errorDialog = new Alert(Alert.AlertType.ERROR);
                errorDialog.setTitle("CHYBA!");
                errorDialog.setHeaderText("Chyba při zadávání dat");
                errorDialog.setContentText("Zřejmě nebyla zadána všechna data... ");               
                errorDialog.showAndWait();
            }
            else{
                // Přidání nového pacienta do DB a jeho následné přidání do ObservableList
                // Dotaz je řešen pomocí PreparedStatement
                try(Connection connectDB = DriverManager.getConnection
                    ("jdbc:mysql://localhost/mysql?user=root&password=");
                        PreparedStatement queryInsert = connectDB.prepareStatement("INSERT INTO Patients"
                                + " VALUES (?,?,?,?,?,?,?)");
                        PreparedStatement querySelect = connectDB.prepareStatement
                                ("SELECT * FROM Patients WHERE patientBCN = ?");
                        ){
                    Long patientPhoneNumber = Long.valueOf(phoneNumberField.getText());
                    
                    int patientYear = Integer.parseInt(yearComboBox.getSelectionModel().getSelectedItem());
                    int patientMonth = Integer.parseInt(monthComboBox.getSelectionModel().getSelectedItem());
                    int patientDay = Integer.parseInt(dayComboBox.getSelectionModel().getSelectedItem());
                    
                    // Převod data narození pacienta (LocalDate) na sql.Date pro databázi
                    java.sql.Date sqlPatientDOB = null;
                    LocalDate locaPatientDOB = LocalDate.of(patientYear, patientMonth, patientDay);
                    sqlPatientDOB = Date.valueOf(locaPatientDOB);
                    
                    // Vkládání parametrů do dotazu
                    queryInsert.setString(1, birthCertificateNumberField.getText());
                    queryInsert.setString(2, nameField.getText());
                    queryInsert.setString(3, surnameField.getText());
                    queryInsert.setString(4, addressField.getText());
                    queryInsert.setDate(5, sqlPatientDOB);
                    queryInsert.setLong(6, patientPhoneNumber);
                    queryInsert.setString(7, genderComboBox.getSelectionModel().getSelectedItem());
                    
                    // Spuštění přidávacího dotazu
                    queryInsert.executeUpdate();
                    queryInsert.close();
                    
                    // Vložení parametru do výběrového dotazu
                    querySelect.setString(1, birthCertificateNumberField.getText());
                    ResultSet selectResult = querySelect.executeQuery();
                    
                    // Vytvoření nového pacienta a přidání do ObservableList
                    selectResult.next();
                    Patient newPatient = new Patient(selectResult.getString("patientBCN"),
                        selectResult.getString("patientName"), selectResult.getString("patientSurname"), 
                        selectResult.getString("patientAddress"), 
                        selectResult.getDate("patientDOB").toLocalDate(), selectResult.getString("patientGender"),
                        selectResult.getLong("patientPhoneNumber"));
                    patientObsList.add(newPatient); 
                }
                // Zachycení výjimky
                catch(SQLException ex){
                    Alert errorDialog = new Alert(Alert.AlertType.ERROR);
                    errorDialog.setTitle("CHYBA!");
                    errorDialog.setHeaderText("Chyba při zadávání dat");
                    errorDialog.setContentText(ex.getMessage());               
                    errorDialog.showAndWait();
                }
                catch(NumberFormatException nfe){
                    Alert errorDialog = new Alert(Alert.AlertType.ERROR);
                    errorDialog.setTitle("CHYBA!");
                    errorDialog.setHeaderText("Chyba při zadávání dat");
                    errorDialog.setContentText("Špatně zadané hodnoty: "+nfe.getMessage());               
                    errorDialog.showAndWait();
                }
            }
        } );
        
        // Obsluha tlačítka pro vymazání pacienta z DB/ObservableList
        deleteButton.setOnAction(e->{
            try(Connection connectDB = DriverManager.getConnection
        ("jdbc:mysql://localhost/mysql?user=root&password=");
                    PreparedStatement queryDelete = connectDB.prepareStatement("DELETE FROM Patients"
                            + " WHERE patientBCN = ?");){
                String selectedPatientBCN = patientTableView.getSelectionModel().
                        getSelectedItem().getBirthCertificateNumber();
                queryDelete.setString(1, selectedPatientBCN);
                queryDelete.executeUpdate();
                
                patientObsList.remove(patientTableView.getSelectionModel().getSelectedItem());
            }
            catch(SQLException ex){
                Alert errorDialog = new Alert(Alert.AlertType.ERROR);
                    errorDialog.setTitle("CHYBA!");
                    errorDialog.setHeaderText("Chyba při plnění dotazu");
                    errorDialog.setContentText(ex.getMessage());               
                    errorDialog.showAndWait();
            }
        });
        
        // Obsluha MenuItem pro zavření okna
        closeMenuItem.setOnAction( e -> {
            Alert confirmDialog = new Alert(AlertType.CONFIRMATION);
            confirmDialog.setTitle("Zavrit okno");
            confirmDialog.setHeaderText("Zavrit okno");
            confirmDialog.setContentText("Jste si jisty, ze chce program zavrit?");
            
            Optional<ButtonType> result = confirmDialog.showAndWait();
            if(result.get() == ButtonType.OK){
                confirmDialog.close();
                primaryStage.close();
            }
            else
                confirmDialog.close();
        });
        
        // Obsluha tlačítka pro vyprázdnění polí
        clearButton.setOnAction( e -> {
            if(nameField.getText() != null ||
                    surnameField.getText() != null ||
                    addressField.getText() != null ||
                    birthCertificateNumberField.getText() != null ||
                    phoneNumberField.getText() != null){
                nameField.clear();
                surnameField.clear();
                addressField.clear();
                birthCertificateNumberField.clear();
                phoneNumberField.clear();
            }
        });
        
        // Obsluha real-time vyhledávání pacientů
        FilteredList<Patient> filteredPatients = new FilteredList<>(patientObsList, e->true);
        filterField.setOnKeyReleased( e -> {
            filterField.textProperty().addListener((observableValue, oldValue, newValue) -> {
                filteredPatients.setPredicate((Predicate<? super Patient>) patient-> {
                    if(newValue == null || newValue.isEmpty())
                        return true;
                    String lowerCaseFiltered = newValue.toLowerCase();
                    if(patient.getName().toLowerCase().contains(lowerCaseFiltered)){
                        return true;
                    }else if(patient.getSurname().toLowerCase().contains(lowerCaseFiltered)){
                        return true;
                    }
                    return false;
                });
            });
            SortedList<Patient> sortedPatients = new SortedList<>(filteredPatients);
            sortedPatients.comparatorProperty().bind(patientTableView.comparatorProperty());
            patientTableView.setItems(sortedPatients);
        });
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
    
}

