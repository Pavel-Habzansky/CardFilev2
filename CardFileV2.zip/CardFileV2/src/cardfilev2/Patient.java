/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cardfilev2;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 *
 * @author PavelHabzansky
 */
public class Patient {
    private String name, surname, address, birthCertificateNumber, gender;
    private LocalDate dateOfBirth;
    private long phoneNumber;
    private long age;
    
    // Konstruktor pacienta
    public Patient(String birthCertificateNumber, String name, String surname, 
            String address, LocalDate dateOfBirth,
            String gender, long phoneNumber){
        this.name = name;
        this.surname = surname;
        this.address = address;
        this.birthCertificateNumber = birthCertificateNumber;
        this.dateOfBirth = dateOfBirth;
        this.gender = gender;
        this.phoneNumber = phoneNumber;
        this.age = getAge();
    }
    
    // Přístupové metody... 
    public long getAge(){
        LocalDate dob = LocalDate.of(this.dateOfBirth.getYear(),
                this.dateOfBirth.getMonthValue(),
                this.dateOfBirth.getDayOfMonth());
        LocalDate today = LocalDate.now();
        this.age = ChronoUnit.YEARS.between(dob, today);
        return age;
    }
    public String getName(){
        return name;
    }
    public String getSurname(){
        return surname;
    }
    public String getAddress(){
        return address;
    }
    public String getBirthCertificateNumber(){
        return birthCertificateNumber;
    }
    public long getPhoneNumber(){
        return phoneNumber;
    }
    public String getGender(){
        return gender;
    }
    public LocalDate getDateOfBirth(){
        return dateOfBirth;
    }
    
}
